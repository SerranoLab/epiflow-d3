# ============================================================================
# plumber.R — EpiFlow D3.js API Endpoints
# Serrano Lab | Boston University
#
# All endpoints return JSON. The frontend calls these to get computed results.
# ============================================================================

library(plumber)
library(jsonlite)

# Source helper functions
# NOTE: plumber::plumb() evaluates this file from its own directory (R/),
# so paths are relative to R/, not api/
source("helpers.R")
source("statistics.R")
source("phase2.R")
source("phase3.R")
source("separation.R")
source("interpret.R")

# In-memory data store (per-session; keyed by upload ID)
# In production, consider Redis or file-based caching
data_store <- new.env(parent = emptyenv())

# ---- CORS configuration ----
# EPIFLOW_CORS_ORIGIN: "*" (default, dev) or a comma-separated allowlist of
# exact origins (production, e.g. "https://epiflow.serranolab.org"). When an
# allowlist is set, only matching origins get an Access-Control-Allow-Origin
# header; everything else is blocked by the browser.
#* @filter cors
function(req, res) {
  allowed <- Sys.getenv("EPIFLOW_CORS_ORIGIN", "*")
  if (identical(allowed, "*")) {
    res$setHeader("Access-Control-Allow-Origin", "*")
  } else {
    origin <- req$HTTP_ORIGIN
    allow_list <- trimws(strsplit(allowed, ",")[[1]])
    if (!is.null(origin) && origin %in% allow_list) {
      res$setHeader("Access-Control-Allow-Origin", origin)
      res$setHeader("Vary", "Origin")
    }
    # else: no ACAO header is set -> the browser blocks the cross-origin read
  }
  res$setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
  res$setHeader("Access-Control-Allow-Headers", "Content-Type, Accept")

  if (req$REQUEST_METHOD == "OPTIONS") {
    res$status <- 200
    return(list())
  }

  plumber::forward()
}

# ===========================================================================
# HEALTH CHECK
# ===========================================================================

#* API health check
#* @get /api/health
function() {
  list(
    status = "ok",
    version = "1.1.0",
    app = "EpiFlow D3.js API",
    r_version = R.version.string,
    timestamp = Sys.time()
  )
}

# ===========================================================================
# DATA UPLOAD & MANAGEMENT
# ===========================================================================

#* Upload an .rds data file
#* @post /api/upload
#* @parser multi
#* @parser octet
#* @serializer json list(auto_unbox = TRUE)
function(req) {
  # Parse multipart form data
  body <- req$body

  if (is.null(body$file)) {
    res$status <- 400
    return(list(error = "No file provided. Use form field 'file'."))
  }

  # Save uploaded file temporarily
  tmp_path <- tempfile(fileext = ".rds")
  
  file_data <- body$file
  
  if (is.raw(file_data)) {
    # Raw bytes (common in newer Plumber)
    writeBin(file_data, tmp_path)
  } else if (is.character(file_data) && length(file_data) == 1 && file.exists(file_data)) {
    # Path to temp file
    file.copy(file_data, tmp_path)
  } else if (is.list(file_data)) {
    # List format — try common field names for the actual data
    if (!is.null(file_data$datapath) && file.exists(file_data$datapath)) {
      file.copy(file_data$datapath, tmp_path)
    } else if (!is.null(file_data$value) && is.raw(file_data$value)) {
      writeBin(file_data$value, tmp_path)
    } else if (!is.null(file_data$content) && is.raw(file_data$content)) {
      writeBin(file_data$content, tmp_path)
    } else {
      # Try to find any raw element in the list
      raw_elem <- Filter(is.raw, file_data)
      if (length(raw_elem) > 0) {
        writeBin(raw_elem[[1]], tmp_path)
      } else {
        cat("Upload debug — file_data structure: ", str(file_data), "\n")
        return(list(error = paste("Unrecognized file format in upload. Type:",
                                  class(file_data), "Names:", paste(names(file_data), collapse=","))))
      }
    }
  } else {
    cat("Upload debug — body$file class: ", class(file_data), "\n")
    return(list(error = paste("Unrecognized file format in upload. Type:",
                              class(file_data))))
  }

  # Load and validate
  result <- tryCatch(
    load_epiflow_data(tmp_path),
    error = function(e) list(error = e$message)
  )

  if ("error" %in% names(result)) {
    return(list(error = result[["error"]]))
  }

  # Generate session ID and store data
  session_id <- generate_session_id("s_")

  data_store[[session_id]] <- list(
    raw_data = result$data,
    filtered_data = result$data,
    metadata = result[setdiff(names(result), "data")],
    created = Sys.time()
  )
  prune_data_store()

  # Session data is kept in memory only (data_store environment)
  # No disk persistence — sessions don't survive container restarts

  response <- list(
    session_id = session_id,
    n_cells = result$n_cells,
    h3_markers = result$h3_markers,
    phenotypic_markers = result$phenotypic_markers,
    genotype_levels = result$genotype_levels,
    identities = result$identities,
    cell_cycles = result$cell_cycles,
    replicates = result$replicates,
    available_meta = result$available_meta,
    palette = result$palette
  )

  # Append dynamic meta_levels (e.g., timepoint_levels, condition_levels)
  meta_level_names <- grep("_levels$", names(result), value = TRUE)
  meta_level_names <- setdiff(meta_level_names, "genotype_levels")
  for (nm in meta_level_names) {
    response[[nm]] <- result[[nm]]
  }

  response
}

#* Get dataset metadata for a session
#* @get /api/metadata/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))
  store$metadata
}

#* Load a built-in synthetic example dataset for demoing the app.
#* Generates the data on the fly (deterministic), runs it through the same
#* validation pipeline as a user upload, and returns the standard payload.
#*
#* Body parameters:
#*   preset           "ipsc_npc" (default) — KMT2D-KO iPSC neural differentiation
#*                    "pbmc_kat6a" — KAT6A haploinsufficiency in PBMCs
#*   seed             RNG seed (per-preset default)
#*   cells_per_rep    Cells per group × replicate (default 600)
#*
#* @post /api/example
#* @serializer json list(auto_unbox = TRUE)
function(req) {
  body <- if (!is.null(req$body)) req$body else list()
  preset <- if (!is.null(body$preset)) as.character(body$preset) else "ipsc_npc"
  cells_per_rep <- if (!is.null(body$cells_per_rep)) as.integer(body$cells_per_rep) else 600L

  # Per-preset defaults (label, generator, default seed)
  preset_meta <- switch(preset,
    "ipsc_npc" = list(
      label = "EpiFlow Demo: iPSC-NPC Differentiation, KMT2D-KO (synthetic)",
      generator = generate_example_data,
      default_seed = 4242L
    ),
    "pbmc_kat6a" = list(
      label = "EpiFlow Demo: PBMC, KAT6A Haploinsufficiency (synthetic)",
      generator = generate_example_pbmc,
      default_seed = 7373L
    ),
    NULL
  )
  if (is.null(preset_meta)) {
    return(list(error = paste0("Unknown preset: '", preset,
                               "'. Valid options: 'ipsc_npc', 'pbmc_kat6a'.")))
  }
  seed <- if (!is.null(body$seed)) as.integer(body$seed) else preset_meta$default_seed

  example_df <- tryCatch(
    preset_meta$generator(seed = seed, cells_per_rep = cells_per_rep),
    error = function(e) NULL
  )
  if (is.null(example_df)) {
    return(list(error = "Failed to generate example dataset."))
  }

  # Save to a tempfile and route through load_epiflow_data() so the example
  # uses the exact same validation/normalization path as a real upload.
  tmp_path <- tempfile(fileext = ".rds")
  saveRDS(example_df, tmp_path)

  result <- tryCatch(load_epiflow_data(tmp_path),
                     error = function(e) list(error = e$message))
  if ("error" %in% names(result)) {
    return(list(error = result[["error"]]))
  }

  session_id <- generate_session_id("ex_")
  data_store[[session_id]] <- list(
    raw_data = result$data,
    filtered_data = result$data,
    metadata = result[setdiff(names(result), "data")],
    created = Sys.time()
  )
  prune_data_store()

  response <- list(
    session_id = session_id,
    is_example = TRUE,
    preset = preset,
    example_label = preset_meta$label,
    n_cells = result$n_cells,
    h3_markers = result$h3_markers,
    phenotypic_markers = result$phenotypic_markers,
    genotype_levels = result$genotype_levels,
    identities = result$identities,
    cell_cycles = result$cell_cycles,
    replicates = result$replicates,
    available_meta = result$available_meta,
    palette = result$palette
  )
  meta_level_names <- grep("_levels$", names(result), value = TRUE)
  meta_level_names <- setdiff(meta_level_names, "genotype_levels")
  for (nm in meta_level_names) {
    response[[nm]] <- result[[nm]]
  }
  response
}

# ===========================================================================
# DATA FILTERING
# ===========================================================================

#* Apply filters and return summary of filtered data
#* @post /api/filter/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))

  params <- req$body
  filtered <- filter_data(
    store$raw_data,
    identities  = params$identities,
    cell_cycles = params$cell_cycles,
    genotypes   = params$genotypes,
    cell_types  = params$cell_types,
    conditions  = params$conditions,
    timepoints  = params$timepoints
  )

  # Generic metadata-column filters. The frontend sends a `meta_filters` object
  # keyed by column name (condition, timepoint, cell_type, treatment, and any
  # auto-detected categorical column). Apply each against the matching column when
  # present. Comparison uses character coercion so numeric levels (e.g. timepoint
  # 0/24/48) match the string values arriving via JSON.
  mf <- params$meta_filters
  if (!is.null(mf) && length(mf) > 0) {
    for (col in names(mf)) {
      vals <- mf[[col]]
      if (!is.null(vals) && length(vals) > 0 && col %in% names(filtered)) {
        keep_vals <- as.character(unlist(vals))
        filtered <- filtered %>%
          dplyr::filter(as.character(.data[[col]]) %in% keep_vals)
      }
    }
  }

  extra_grouping <- character(0)

  # ---- Gate population column + filtering ----
  gm <- params$gating_metadata
  if (!is.null(gm) && !is.null(gm$marker_x) && !is.null(gm$marker_y)) {
    mx <- gm$marker_x
    my <- gm$marker_y
    tx <- as.numeric(gm$threshold_x)
    ty <- as.numeric(gm$threshold_y)
    labels <- gm$labels  # named list: Q1 -> "name", Q2 -> "name", etc.

    if (!is.na(tx) && !is.na(ty)) {
      cell_data <- filtered
      # Get marker values per cell
      vals_x <- NULL; vals_y <- NULL

      if ("H3PTM" %in% names(cell_data)) {
        vals_x <- cell_data %>% dplyr::filter(H3PTM == mx) %>%
          dplyr::distinct(cell_id, .keep_all = TRUE) %>%
          dplyr::select(cell_id, value) %>% dplyr::rename(val_x = value)
        vals_y <- cell_data %>% dplyr::filter(H3PTM == my) %>%
          dplyr::distinct(cell_id, .keep_all = TRUE) %>%
          dplyr::select(cell_id, value) %>% dplyr::rename(val_y = value)
      }
      # Fallback to wide-format columns
      if ((is.null(vals_x) || nrow(vals_x) == 0) && mx %in% names(cell_data)) {
        vals_x <- cell_data %>% dplyr::distinct(cell_id, .keep_all = TRUE) %>%
          dplyr::select(cell_id, val_x = !!dplyr::sym(mx))
      }
      if ((is.null(vals_y) || nrow(vals_y) == 0) && my %in% names(cell_data)) {
        vals_y <- cell_data %>% dplyr::distinct(cell_id, .keep_all = TRUE) %>%
          dplyr::select(cell_id, val_y = !!dplyr::sym(my))
      }

      if (!is.null(vals_x) && !is.null(vals_y) && nrow(vals_x) > 0 && nrow(vals_y) > 0) {
        gate_df <- dplyr::inner_join(vals_x, vals_y, by = "cell_id") %>%
          dplyr::mutate(
            quadrant = dplyr::case_when(
              val_x >= tx & val_y >= ty ~ "Q2",
              val_x <  tx & val_y >= ty ~ "Q1",
              val_x <  tx & val_y <  ty ~ "Q3",
              val_x >= tx & val_y <  ty ~ "Q4",
              TRUE ~ NA_character_
            ),
            gate_population = dplyr::case_when(
              quadrant == "Q1" ~ as.character(labels$Q1 %||% "Q1"),
              quadrant == "Q2" ~ as.character(labels$Q2 %||% "Q2"),
              quadrant == "Q3" ~ as.character(labels$Q3 %||% "Q3"),
              quadrant == "Q4" ~ as.character(labels$Q4 %||% "Q4"),
              TRUE ~ NA_character_
            )
          ) %>%
          dplyr::select(cell_id, gate_population)

        # Join gate_population to filtered data
        filtered <- filtered %>%
          dplyr::left_join(gate_df, by = "cell_id")

        extra_grouping <- c(extra_grouping, "gate_population")

        # Filter by selected quadrants if specified
        sel_q <- unlist(gm$selected_quadrants)
        if (!is.null(sel_q) && length(sel_q) > 0) {
          # Map selected quadrant codes to population labels
          sel_labels <- sapply(sel_q, function(q) as.character(labels[[q]] %||% q))
          filtered <- filtered %>% dplyr::filter(gate_population %in% sel_labels)
        }
      }
    }
  } else {
    # Remove gate_population column if no gating active
    if ("gate_population" %in% names(filtered)) {
      filtered <- filtered %>% dplyr::select(-gate_population)
    }
  }

  # ---- Cluster identity column + filtering ----
  cm <- params$cluster_metadata
  if (!is.null(cm) && !is.null(cm$name_map) && !is.null(cm$cell_assignments)) {
    name_map <- cm$name_map
    cell_assigns <- cm$cell_assignments

    if (length(name_map) > 0 && length(cell_assigns) > 0) {
      # Build cell_id → cluster_identity mapping
      assign_df <- data.frame(
        cell_id = names(cell_assigns),
        cluster_num = as.character(unlist(cell_assigns)),
        stringsAsFactors = FALSE
      )
      # Map cluster numbers to names
      cmap <- setNames(as.character(unlist(name_map)), names(name_map))
      assign_df$cluster_identity <- cmap[assign_df$cluster_num]
      assign_df$cluster_identity[is.na(assign_df$cluster_identity)] <-
        paste0("Cluster ", assign_df$cluster_num[is.na(assign_df$cluster_identity)])

      # Match cell_id types before joining
      assign_df$cell_id <- as(assign_df$cell_id, class(filtered$cell_id))

      # Join to filtered data
      filtered <- filtered %>%
        dplyr::left_join(assign_df %>% dplyr::select(cell_id, cluster_identity), by = "cell_id")

      # Cells not in clustering get NA — fill with "Unassigned"
      filtered$cluster_identity[is.na(filtered$cluster_identity)] <- "Unassigned"

      extra_grouping <- c(extra_grouping, "cluster_identity")

      # Filter by selected clusters if specified
      sel_clusters <- unlist(cm$selected_clusters)
      if (!is.null(sel_clusters) && length(sel_clusters) > 0) {
        sel_names <- cmap[as.character(sel_clusters)]
        sel_names <- sel_names[!is.na(sel_names)]
        if (length(sel_names) > 0) {
          filtered <- filtered %>% dplyr::filter(cluster_identity %in% sel_names)
        }
      }
    }
  } else {
    # Remove cluster_identity column if no clustering active
    if ("cluster_identity" %in% names(filtered)) {
      filtered <- filtered %>% dplyr::select(-cluster_identity)
    }
  }

  data_store[[session_id]]$filtered_data <- filtered

  n_cells <- dplyr::n_distinct(filtered$cell_id)

  list(
    n_cells = n_cells,
    n_rows = nrow(filtered),
    identities = sort(unique(filtered$identity)),
    cell_cycles = sort(unique(filtered$cell_cycle)),
    genotypes = sort(unique(filtered$genotype)),
    extra_grouping = extra_grouping
  )
}

#* Store cluster identity name mapping and cell assignments
#* @post /api/cluster-identities/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))

  params <- req$body
  name_map <- params$name_map

  # Store name map (can be empty to clear)
  if (is.null(name_map) || length(name_map) == 0) {
    data_store[[session_id]]$cluster_identity_map <- NULL
    data_store[[session_id]]$cluster_cell_assignments <- NULL
    return(list(status = "cleared"))
  }

  cmap <- setNames(as.character(unlist(name_map)), names(name_map))
  data_store[[session_id]]$cluster_identity_map <- cmap

  # Store cell → cluster assignments if provided
  cell_assignments <- params$cell_assignments
  if (!is.null(cell_assignments)) {
    data_store[[session_id]]$cluster_cell_assignments <- cell_assignments
  }

  list(
    status = "ok",
    cluster_names = as.list(cmap)
  )
}

# ===========================================================================
# DATA OVERVIEW
# ===========================================================================

#* Get data overview statistics
#* @post /api/data/overview/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))

  data <- store$filtered_data
  meta <- store$metadata

  # Unique cells
  cells <- data %>% dplyr::distinct(cell_id, .keep_all = TRUE)
  n_cells <- nrow(cells)

  # Genotype/condition column
  geno_col <- meta$genotype_col %||% "genotype"
  if (!geno_col %in% names(cells)) geno_col <- "genotype"

  # Cells per condition
  condition_counts <- cells %>%
    dplyr::count(.data[[geno_col]], name = "n") %>%
    dplyr::arrange(dplyr::desc(n))

  # Cells per identity
  identity_counts <- if ("identity" %in% names(cells)) {
    cells %>% dplyr::count(identity, name = "n") %>% dplyr::arrange(dplyr::desc(n))
  } else { data.frame(identity = "N/A", n = n_cells) }

  # Cells per cell cycle
  cycle_counts <- if ("cell_cycle" %in% names(cells)) {
    cells %>% dplyr::count(cell_cycle, name = "n") %>% dplyr::arrange(dplyr::desc(n))
  } else { data.frame(cell_cycle = "N/A", n = n_cells) }

  # Cells per replicate
  replicate_counts <- if ("replicate" %in% names(cells)) {
    cells %>% dplyr::count(replicate, name = "n") %>% dplyr::arrange(dplyr::desc(n))
  } else { data.frame(replicate = "N/A", n = n_cells) }

  # H3-PTM marker summary stats
  h3_markers <- meta$h3_markers %||% character(0)
  marker_stats <- lapply(h3_markers, function(m) {
    vals <- data$value[data$H3PTM == m]
    vals <- vals[!is.na(vals)]
    list(
      marker = m,
      mean = mean(vals),
      median = median(vals),
      sd = sd(vals),
      min = min(vals),
      max = max(vals),
      n = length(vals)
    )
  })

  # Phenotypic marker stats
  pheno_markers <- meta$phenotypic_markers %||% character(0)
  pheno_stats <- lapply(pheno_markers, function(m) {
    if (!m %in% names(cells)) return(NULL)
    vals <- cells[[m]]
    vals <- vals[!is.na(vals)]
    list(
      marker = m,
      mean = mean(vals),
      median = median(vals),
      sd = sd(vals),
      min = min(vals),
      max = max(vals),
      n = length(vals)
    )
  })
  pheno_stats <- Filter(Negate(is.null), pheno_stats)

  # Cross-tab: condition × identity
  cross_tab <- NULL
  if ("identity" %in% names(cells)) {
    cross_tab <- cells %>%
      dplyr::count(.data[[geno_col]], identity, name = "n") %>%
      tidyr::pivot_wider(names_from = identity, values_from = n, values_fill = 0)
  }

  # Available metadata columns
  avail_meta <- meta$available_meta %||% character(0)

  # Condition × cell cycle cross-tab
  cond_cycle_tab <- NULL
  if ("cell_cycle" %in% names(cells)) {
    cond_cycle_tab <- cells %>%
      dplyr::count(.data[[geno_col]], cell_cycle, name = "n")
  }

  # Replicate × condition cross-tab
  replicate_cond_tab <- NULL
  if ("replicate" %in% names(cells)) {
    replicate_cond_tab <- cells %>%
      dplyr::count(.data[[geno_col]], replicate, name = "n")
  }

  # Identity × condition cross-tab (long form for grouped bar)
  identity_cond_tab <- NULL
  if ("identity" %in% names(cells)) {
    identity_cond_tab <- cells %>%
      dplyr::count(.data[[geno_col]], identity, name = "n")
  }

  # Marker stats stratified by condition
  marker_stats_by_cond <- lapply(h3_markers, function(m) {
    conds <- sort(unique(data[[geno_col]]))
    lapply(conds, function(cond) {
      vals <- data$value[data$H3PTM == m & data[[geno_col]] == cond]
      vals <- vals[!is.na(vals)]
      if (length(vals) < 2) return(NULL)
      list(
        marker = m,
        condition = cond,
        mean = mean(vals),
        median = median(vals),
        sd = sd(vals),
        min = min(vals),
        max = max(vals),
        n = length(vals)
      )
    })
  })
  marker_stats_by_cond <- Filter(Negate(is.null), unlist(marker_stats_by_cond, recursive = FALSE))

  list(
    n_cells = n_cells,
    n_h3_markers = length(h3_markers),
    n_pheno_markers = length(pheno_markers),
    n_conditions = dplyr::n_distinct(cells[[geno_col]]),
    n_identities = if ("identity" %in% names(cells)) dplyr::n_distinct(cells$identity) else 0,
    n_replicates = if ("replicate" %in% names(cells)) dplyr::n_distinct(cells$replicate) else 0,
    n_cycles = if ("cell_cycle" %in% names(cells)) dplyr::n_distinct(cells$cell_cycle) else 0,
    condition_col = geno_col,
    condition_counts = condition_counts,
    identity_counts = identity_counts,
    cycle_counts = cycle_counts,
    replicate_counts = replicate_counts,
    h3_markers = safe_I(h3_markers),
    pheno_markers = safe_I(pheno_markers),
    marker_stats = safe_I(marker_stats),
    pheno_stats = safe_I(pheno_stats),
    cross_tab = cross_tab,
    cond_cycle_tab = cond_cycle_tab,
    replicate_cond_tab = replicate_cond_tab,
    identity_cond_tab = identity_cond_tab,
    marker_stats_by_cond = safe_I(marker_stats_by_cond),
    available_meta = safe_I(avail_meta)
  )
}

# ===========================================================================
# VISUALIZATION DATA ENDPOINTS
# ===========================================================================

#* Get ridge plot density data
#* @post /api/viz/ridge/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))

  params <- req$body
  tryCatch(
    if (identical(params$group_by, "marker") || identical(params$color_by, "marker")) {
      compute_ridge_overlay(
        store$filtered_data,
        markers    = params$markers,
        group_by   = params$group_by %||% "genotype",
        color_by   = params$color_by %||% "marker",
        h3_markers = store$metadata$h3_markers,
        bw         = params$bandwidth %||% "auto",
        scale_mode = params$scale_mode %||% "robust"
      )
    } else {
      compute_ridge_data(
        store$filtered_data,
        marker     = params$marker %||% store$metadata$h3_markers[1],
        group_by   = params$group_by %||% "genotype",
        color_by   = params$color_by %||% "genotype",
        bw         = params$bandwidth %||% "auto",
        h3_markers = store$metadata$h3_markers
      )
    },
    error = function(e) list(error = paste("Ridge computation failed:", e$message))
  )
}

#* Get violin plot data
#* @post /api/viz/violin/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))

  params <- req$body
  compute_violin_data(
    store$filtered_data,
    marker     = params$marker %||% store$metadata$h3_markers[1],
    group_by   = params$group_by %||% "genotype",
    color_by   = params$color_by,
    h3_markers = store$metadata$h3_markers
  )
}

#* Get heatmap data (identity x marker z-scores)
#* @post /api/viz/heatmap/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))

  params <- req$body
  compute_identity_heatmap(
    store$filtered_data,
    group_by = params$group_by %||% "identity",
    include_phenotypic = isTRUE(params$include_phenotypic),
    phenotypic_markers = store$metadata$phenotypic_markers
  )
}

#* Get cell cycle distribution
#* @post /api/viz/cellcycle/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))

  params <- req$body
  compute_cycle_distribution(
    store$filtered_data,
    comparison_var = params$comparison_var %||% "genotype"
  )
}

#* Per-phase H3-PTM marker analysis
#* @post /api/viz/cellcycle-markers/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))

  params <- req$body
  geno_col <- store$metadata$genotype_col %||% "genotype"
  compute_cycle_marker_analysis(
    store$filtered_data,
    phase = params$phase %||% "all",
    comparison_var = params$comparison_var %||% geno_col
  )
}

# ===========================================================================
# STATISTICS ENDPOINTS
# ===========================================================================

#* Run LMM for a single marker
#* @post /api/stats/lmm/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))

  params <- req$body
  result <- fit_stratified_lmm(
    store$filtered_data,
    marker          = params$marker,
    stratify_by     = params$stratify_by,
    ref_level       = params$ref_level,
    comparison_var  = params$comparison_var %||% "genotype",
    h3_marks        = store$metadata$h3_markers,
    use_cells_as_replicates = isTRUE(params$use_cells_as_replicates)
  )

  if (is.null(result)) return(list(error = "Model could not be fit"))
  list(results = result)
}

#* Run LMM across all selected markers
#* @post /api/stats/all-markers/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))

  params <- req$body
  # Use selected markers from frontend, fall back to all H3-PTMs
  markers <- params$markers %||% store$metadata$h3_markers
  if (!is.null(params$selected_markers)) markers <- params$selected_markers

  result <- tryCatch(
    run_all_markers_lmm(
      store$filtered_data,
      markers         = markers,
      comparison_var  = params$comparison_var %||% "genotype",
      stratify_by     = params$stratify_by,
      ref_level       = params$ref_level,
      h3_markers      = store$metadata$h3_markers,
      use_cells_as_replicates = isTRUE(params$use_cells_as_replicates)
    ),
    error = function(e) list(error = paste("Analysis failed:", e$message))
  )

  if ("error" %in% names(result)) return(result)
  if (is.null(result)) return(list(error = "No models could be fit — check that the comparison variable has at least 2 levels in the filtered data."))

  # Add EMD + KS distribution metrics per (marker, subset, contrast) for the
  # heatmap toggle. Cheap (sub-second for typical datasets); always computed.
  result <- tryCatch(
    add_distribution_metrics(
      result, store$filtered_data,
      comparison_var = params$comparison_var %||% "genotype",
      stratify_by    = params$stratify_by,
      h3_markers     = store$metadata$h3_markers
    ),
    error = function(e) {
      cat("Distribution metrics failed:", e$message, "\n"); result
    }
  )

  # BH adjustment on KS p-values too, parallel to LMM p_adj
  if ("ks_p_value" %in% names(result) && sum(!is.na(result$ks_p_value)) > 1) {
    result$ks_p_adj <- p.adjust(result$ks_p_value, method = "BH")
  }

  # Determine replicate counts for caution notes
  caution_notes <- list()
  if ("n_reps" %in% names(result)) {
    min_reps <- min(result$n_reps, na.rm = TRUE)
    if (!is.na(min_reps) && min_reps < 5) {
      caution_notes <- c(caution_notes, list(
        paste0("LMM p-values with < 5 replicates per group (min observed: ", min_reps,
               ") should be interpreted cautiously. The random effect variance may be unstable. Consider Cohen's d as the primary metric.")
      ))
    }
  }
  caution_notes <- c(caution_notes, list(
    "Cohen's d confidence intervals use cell-level N, making them artificially narrow (~100\u00d7 too narrow). The d point estimate is valid; the CI width underestimates true uncertainty."
  ))

  list(results = result, caution_notes = caution_notes)
}

#* All-pairwise LMM contrasts + replicate-level EMD test for ONE marker.
#* Surfaces lmm_pairwise() (every pairwise comparison, not just vs-reference)
#* and replicate_emd_test() (per-replicate EMD + Wilcoxon/Kruskal).
#* @post /api/stats/marker-detail/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))

  params <- req$body
  marker <- params$marker
  if (is.null(marker)) return(list(error = "No marker specified"))
  comp  <- params$comparison_var %||% "genotype"
  ref   <- params$ref_level
  strat <- if (!is.null(params$stratify_by) && params$stratify_by != "None") params$stratify_by else NULL

  pw <- tryCatch(
    lmm_pairwise(store$filtered_data, marker = marker, stratify_by = strat,
                 ref_level = ref, comparison_var = comp,
                 h3_marks = store$metadata$h3_markers,
                 use_cells_as_replicates = isTRUE(params$use_cells_as_replicates)),
    error = function(e) NULL)

  emd <- tryCatch(
    replicate_emd_test(store$filtered_data, marker = marker,
                       comparison_var = comp, ref_level = ref,
                       h3_marks = store$metadata$h3_markers),
    error = function(e) list(error = e$message))

  list(
    marker = marker,
    comparison_var = comp,
    pairwise = if (is.data.frame(pw) && nrow(pw) > 0) pw else list(),
    pairwise_note = if (!is.data.frame(pw) || nrow(pw) == 0)
      "No pairwise result — need >= 2 groups with sufficient cells." else NULL,
    emd = emd
  )
}
#* @post /api/stats/correlation/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))

  params <- req$body
  compute_correlations(
    store$filtered_data,
    h3_markers = store$metadata$h3_markers,
    method = params$method %||% "pearson",
    include_phenotypic = isTRUE(params$include_phenotypic),
    phenotypic_markers = store$metadata$phenotypic_markers,
    selected_markers = params$selected_markers
  )
}

# ===========================================================================
# PHASE 2: POSITIVITY / GMM
# ===========================================================================

#* Compute positivity / GMM analysis for a marker
#* @post /api/phase2/positivity/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))

  params <- req$body
  geno_col <- store$metadata$genotype_col %||% "genotype"
  tryCatch(
    compute_positivity(
      store$filtered_data,
      marker = params$marker,
      comparison_var = params$comparison_var %||% geno_col,
      h3_markers = store$metadata$h3_markers,
      manual_threshold = if (!is.null(params$threshold)) as.numeric(params$threshold) else NULL
    ),
    error = function(e) list(error = paste("Positivity failed:", e$message))
  )
}

# ===========================================================================
# PHASE 2: PER-GROUP + DIFFERENTIAL CORRELATION
# ===========================================================================

#* Per-group correlation + differential correlation analysis
#* @post /api/phase2/correlation-diff/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))

  params <- req$body
  geno_col <- store$metadata$genotype_col %||% "genotype"
  tryCatch(
    compute_per_group_correlation(
      store$filtered_data,
      h3_markers = store$metadata$h3_markers,
      group_by = params$group_by %||% geno_col,
      method = params$method %||% "pearson",
      include_phenotypic = isTRUE(params$include_phenotypic),
      phenotypic_markers = store$metadata$phenotypic_markers,
      use_cell_n = isTRUE(params$use_cell_n)
    ),
    error = function(e) list(error = paste("Differential correlation failed:", e$message))
  )
}

# ===========================================================================
# PHASE 2: QUADRANT GATING
# ===========================================================================

#* Compute gating scatter + quadrant stats
#* @post /api/phase2/gating/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))

  params <- req$body
  geno_col <- store$metadata$genotype_col %||% "genotype"
  all_markers <- c(store$metadata$h3_markers, store$metadata$phenotypic_markers)

  # Apply optional identity/cell cycle filters
  filt_data <- store$filtered_data
  if (!is.null(params$filter_identity) && params$filter_identity != "All" &&
      "identity" %in% names(filt_data)) {
    filt_data <- filt_data %>% dplyr::filter(identity == params$filter_identity)
  }
  if (!is.null(params$filter_cycle) && params$filter_cycle != "All" &&
      "cell_cycle" %in% names(filt_data)) {
    filt_data <- filt_data %>% dplyr::filter(cell_cycle == params$filter_cycle)
  }

  tryCatch(
    compute_gating(
      filt_data,
      marker_x = params$marker_x %||% all_markers[1],
      marker_y = params$marker_y %||% all_markers[min(2, length(all_markers))],
      threshold_x = if (!is.null(params$threshold_x)) as.numeric(params$threshold_x) else NULL,
      threshold_y = if (!is.null(params$threshold_y)) as.numeric(params$threshold_y) else NULL,
      comparison_var = params$comparison_var %||% geno_col,
      h3_markers = store$metadata$h3_markers,
      max_points = as.integer(params$max_points %||% 15000)
    ),
    error = function(e) list(error = paste("Gating failed:", e$message))
  )
}

#* Get detailed H3-PTM densities + cell cycle for a selected gating quadrant
#* @post /api/phase2/gating-detail/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))

  params <- req$body
  geno_col <- store$metadata$genotype_col %||% "genotype"
  tryCatch(
    compute_quadrant_detail(
      store$filtered_data,
      marker_x = params$marker_x,
      marker_y = params$marker_y,
      threshold_x = as.numeric(params$threshold_x),
      threshold_y = as.numeric(params$threshold_y),
      quadrant = params$quadrant,
      comparison_var = params$comparison_var %||% geno_col,
      h3_markers = store$metadata$h3_markers
    ),
    error = function(e) list(error = paste("Quadrant detail failed:", e$message))
  )
}

# ===========================================================================
# DIMENSIONALITY REDUCTION
# ===========================================================================

#* Run PCA
#* @post /api/dimred/pca/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))

  params <- req$body
  compute_pca(
    store$filtered_data,
    include_phenotypic  = isTRUE(params$include_phenotypic),
    phenotypic_markers  = store$metadata$phenotypic_markers
  )
}

#* Run UMAP
#* @post /api/dimred/umap/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))

  if (!requireNamespace("uwot", quietly = TRUE)) {
    return(list(error = "uwot package not installed"))
  }

  params <- req$body
  data <- store$filtered_data
  h3_markers <- store$metadata$h3_markers

  meta_base <- c("cell_id", "genotype", "replicate", "cell_cycle", "identity")
  meta_extra <- intersect(c("timepoint", "cell_type", "condition"), names(data))
  meta_all <- c(meta_base, meta_extra)

  wide <- data %>%
    dplyr::select(dplyr::all_of(c(meta_all, "H3PTM", "value"))) %>%
    dplyr::group_by(dplyr::across(dplyr::all_of(meta_all)), H3PTM) %>%
    dplyr::summarise(value = mean(value, na.rm = TRUE), .groups = "drop") %>%
    tidyr::pivot_wider(names_from = H3PTM, values_from = value) %>%
    tidyr::drop_na()

  h3_cols <- intersect(h3_markers, names(wide))

  # Subsample
  max_cells <- params$max_cells %||% 80000
  if (nrow(wide) > max_cells) {
    set.seed(42)
    wide <- wide[sample(nrow(wide), max_cells), ]
  }

  n_neighbors <- params$n_neighbors %||% 15

  umap_result <- uwot::umap(
    as.matrix(wide[, h3_cols]),
    n_neighbors = n_neighbors,
    min_dist = 0.1,
    n_components = 2,
    scale = TRUE
  )

  result_df <- data.frame(
    UMAP1 = umap_result[, 1],
    UMAP2 = umap_result[, 2]
  )
  result_df <- dplyr::bind_cols(result_df,
    wide %>% dplyr::select(dplyr::all_of(intersect(meta_all, names(wide)))))

  if (nrow(result_df) > 10000) {
    set.seed(42)
    result_df <- result_df[sample(nrow(result_df), 10000), ]
  }

  list(
    embedding = result_df,
    n_cells = nrow(result_df),
    n_neighbors = n_neighbors
  )
}

# ===========================================================================
# PHASE 3: UMAP 3D, ADVANCED CLUSTERING
# ===========================================================================

#* UMAP embedding (2D with marker intensities for FeaturePlot)
#* @post /api/phase3/umap/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))
  params <- req$body
  tryCatch(
    compute_umap(
      store$filtered_data,
      h3_markers          = store$metadata$h3_markers,
      phenotypic_markers  = store$metadata$phenotypic_markers,
      n_neighbors         = params$n_neighbors %||% 15,
      min_dist            = params$min_dist %||% 0.1,
      include_phenotypic  = isTRUE(params$include_phenotypic),
      max_cells           = params$max_cells %||% 80000
    ),
    error = function(e) list(error = paste("UMAP failed:", e$message))
  )
}

#* PCA embedding (with 3+ components for 3D)
#* @post /api/phase3/pca/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))
  params <- req$body
  tryCatch(
    compute_pca_3d(
      store$filtered_data,
      include_phenotypic = isTRUE(params$include_phenotypic),
      phenotypic_markers = store$metadata$phenotypic_markers,
      n_components       = params$n_components %||% 5
    ),
    error = function(e) list(error = paste("PCA failed:", e$message))
  )
}

#* Advanced clustering (k-means / hierarchical / Louvain / Leiden)
#* @post /api/phase3/clustering/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))
  params <- req$body
  tryCatch(
    run_advanced_clustering(
      store$filtered_data,
      h3_markers          = store$metadata$h3_markers,
      phenotypic_markers  = store$metadata$phenotypic_markers,
      n_clusters          = params$n_clusters %||% 3,
      method              = params$method %||% "kmeans",
      linkage             = params$linkage %||% "ward.D2",
      resolution          = params$resolution %||% 1.0,
      include_phenotypic  = isTRUE(params$include_phenotypic),
      max_cells           = params$max_cells %||% 50000
    ),
    error = function(e) list(error = paste("Clustering failed:", e$message))
  )
}

#* Elbow / silhouette scan for optimal k
#* @post /api/phase3/elbow/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))
  params <- req$body
  k_max <- min(as.integer(params$k_max %||% 10), 15)
  tryCatch(
    compute_elbow(
      store$filtered_data,
      h3_markers = store$metadata$h3_markers,
      k_range    = 2:k_max
    ),
    error = function(e) list(error = paste("Elbow scan failed:", e$message))
  )
}

# ===========================================================================
# MACHINE LEARNING
# ===========================================================================

#* Run Random Forest classifier
#* @post /api/ml/randomforest/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))

  params <- req$body
  tryCatch(
    run_random_forest(
      store$filtered_data,
      target_var         = params$target_var %||% "genotype",
      h3_markers         = store$metadata$h3_markers,
      phenotypic_markers = store$metadata$phenotypic_markers,
      selected_features  = params$selected_features,
      n_trees            = params$n_trees %||% 500,
      train_fraction     = params$train_fraction %||% 0.7
    ),
    error = function(e) {
      msg <- e$message
      if (grepl("contrasts|factor|level", msg, ignore.case = TRUE))
        msg <- "Classification failed — the target variable may need more than 1 level in the filtered data, or has too many levels for the sample size."
      list(error = msg)
    }
  )
}

#* Run clustering (K-means or PAM)
#* @post /api/ml/clustering/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))

  params <- req$body
  run_clustering(
    store$filtered_data,
    h3_markers = store$metadata$h3_markers,
    n_clusters = params$n_clusters %||% 3,
    method     = params$method %||% "kmeans",
    max_cells  = params$max_cells %||% 50000
  )
}

#* Run Gradient Boosted Model
#* @post /api/ml/gbm/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))

  params <- req$body
  tryCatch(
    run_gbm(
      store$filtered_data,
      target_var         = params$target_var %||% "genotype",
      h3_markers         = store$metadata$h3_markers,
      phenotypic_markers = store$metadata$phenotypic_markers,
      selected_features  = params$selected_features,
      n_trees            = params$n_trees %||% 200,
      train_fraction     = params$train_fraction %||% 0.7
    ),
    error = function(e) {
      msg <- e$message
      if (grepl("contrasts|factor|level|classes", msg, ignore.case = TRUE))
        msg <- "GBM classification failed — the target variable needs at least 2 levels with sufficient data in each."
      if (grepl("xgboost", msg, ignore.case = TRUE))
        msg <- "xgboost package not installed. Run: install.packages('xgboost')"
      list(error = msg)
    }
  )
}

#* Extract H3-PTM signatures per group
#* @post /api/ml/signatures/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))

  params <- req$body
  tryCatch(
    compute_signatures(
      store$filtered_data,
      target_var = params$target_var %||% "genotype",
      h3_markers = params$selected_markers %||% store$metadata$h3_markers
    ),
    error = function(e) list(error = paste("Signatures failed:", e$message))
  )
}

#* Enhanced signatures with diagnostic assessment
#* @post /api/ml/signatures-diagnostic/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))

  params <- req$body
  tryCatch(
    compute_signatures_diagnostic(
      store$filtered_data,
      target_var = params$target_var %||% "genotype",
      h3_markers = params$selected_markers %||% store$metadata$h3_markers,
      stratify_by = if (!is.null(params$stratify_by) && params$stratify_by != "None") params$stratify_by else NULL,
      n_clusters = if (!is.null(params$n_clusters)) as.integer(params$n_clusters) else NULL
    ),
    error = function(e) list(error = paste("Diagnostic analysis failed:", e$message))
  )
}

# ===========================================================================
# HELPER: session retrieval
# ===========================================================================

get_session <- function(session_id) {
  # Reject anything outside [A-Za-z0-9_]; closes path traversal via the
  # file.path() below and keeps lookups to safe keys only.
  session_id <- sanitize_session_id(session_id)
  if (!nzchar(session_id)) return(NULL)

  if (exists(session_id, envir = data_store)) {
    return(data_store[[session_id]])
  }

  # Try loading from disk
  rds_path <- file.path("data", paste0(session_id, ".rds"))
  if (file.exists(rds_path)) {
    data <- readRDS(rds_path)
    result <- tryCatch(load_epiflow_data(rds_path), error = function(e) NULL)
    if (!is.null(result) && !"error" %in% names(result)) {
      data_store[[session_id]] <- list(
        raw_data = result$data,
        filtered_data = result$data,
        metadata = result[setdiff(names(result), "data")],
        created = Sys.time()
      )
      return(data_store[[session_id]])
    }
  }

  NULL
}

#' Bound in-memory data store size (DoS guard): when the number of sessions
#' exceeds max_sessions, drop the oldest by creation time.
prune_data_store <- function(max_sessions = 100) {
  ids <- ls(envir = data_store)
  if (length(ids) <= max_sessions) return(invisible(NULL))
  created <- vapply(ids, function(k) {
    ct <- data_store[[k]]$created
    if (is.null(ct)) 0 else as.numeric(ct)
  }, numeric(1))
  drop <- ids[order(created)][seq_len(length(ids) - max_sessions)]
  if (length(drop)) rm(list = drop, envir = data_store)
  invisible(NULL)
}

# ============================================================================
# Titration & Separation endpoints  (uses separation.R + interpret.R)
# ============================================================================

#* Detect available controls (Q1-Q4) and assess negative quality
#* @post /api/controls/detect/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))
  d <- store$filtered_data
  if (!"condition" %in% names(d)) return(list(error = "No 'condition' column; not a titration dataset."))
  p <- req$body
  floor_cond <- p$blank_condition %||% "BLANK"
  pos_ids <- p$pos_ids %||% setdiff(unique(d$identity), c("Unstained", "Apoptotic Cells"))
  controls <- detect_controls(d, blank_condition = floor_cond,
                              unstained_ident = p$unstained_ident %||% "Unstained",
                              apoptotic_ident = p$apoptotic_ident %||% "Apoptotic Cells")
  rec <- recommend_negative(controls, data = d, pos_ids = pos_ids, floor_condition = floor_cond)
  list(
    controls = controls,
    recommended_negative = list(type = rec$type, confidence = rec$confidence, caveat = rec$caveat),
    quality = if (is.null(rec$quality)) NULL else list(verdict = rec$quality$verdict,
                                                       mean_frac = rec$quality$mean_frac),
    positive_identities = safe_I(pos_ids),
    doses = safe_I(sort(unique(d$condition[d$condition != floor_cond])))
  )
}

#* General A-vs-B separation score for one or more markers (current filter)
#* @post /api/separation/score/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))
  d <- store$filtered_data
  p <- req$body
  pos_ids <- p$pos_ids; neg_ids <- p$neg_ids
  if (is.null(pos_ids) || is.null(neg_ids)) return(list(error = "pos_ids and neg_ids are required"))
  markers <- p$markers %||% store$metadata$h3_markers
  if (!is.null(p$condition) && "condition" %in% names(d)) d <- d %>% dplyr::filter(condition == p$condition)
  assert_arcsinh(d$value)
  scores <- lapply(markers, function(m) {
    md <- d[d$H3PTM == m, ]
    s <- separation_score(md$value[md$identity %in% pos_ids], md$value[md$identity %in% neg_ids])
    c(list(marker = m), s)
  })
  list(scores = scores, positive = safe_I(pos_ids), negative = safe_I(neg_ids))
}

#* Titration sweep with recommendation + plain-language interpretation
#* @post /api/titration/sweep/<session_id>
#* @serializer json list(auto_unbox = TRUE)
function(session_id, req) {
  store <- get_session(session_id)
  if (is.null(store)) return(list(error = "Session not found"))
  d <- store$filtered_data
  if (!"condition" %in% names(d)) return(list(error = "No 'condition' column; not a titration dataset."))
  p <- req$body
  floor_cond <- p$blank_condition %||% "BLANK"
  markers <- p$markers %||% store$metadata$h3_markers
  pos_ids <- p$pos_ids %||% setdiff(unique(d$identity), c("Unstained", "Apoptotic Cells"))
  reference <- p$reference %||% "population"

  # ---- Cell-cycle reference mode: titrate against an endogenous cycle contrast ----
  # (draft) Uses cell_cycle phases as the A-vs-B populations, no antibody-negative
  # control needed. Default contrast: G2/M vs G1. See separation.R for the engine.
  if (reference == "cellcycle") {
    if (!"cell_cycle" %in% names(d)) return(list(error = "No 'cell_cycle' column in this dataset."))
    if (!is.null(p$identity_filter) && length(p$identity_filter) > 0 && "identity" %in% names(d)) {
      d <- d[d$identity %in% p$identity_filter, ]
      if (nrow(d) == 0) return(list(error = "No cells in the selected identity."))
    }
    ph_hi <- p$cc_high; if (is.null(ph_hi)) ph_hi <- c("G2", "M")
    ph_lo <- p$cc_low;  if (is.null(ph_lo)) ph_lo <- c("G0/G1")
    lab_hi <- paste(ph_hi, collapse = "/"); lab_lo <- paste(ph_lo, collapse = "/")
    matched_dna <- setequal(ph_hi, "M") && setequal(ph_lo, "G2")   # both ~4N, copy number cancels
    # Raw phase-resolved intensity (no normalization): cell-cycle changes, including
    # DNA amount and chromatin compaction, are biology the user should see (per the paper).
    results <- lapply(markers, function(m) {
      sw <- titration_sweep(d, m, pos_ids = ph_hi, neg_ids = ph_lo, ref_col = "cell_cycle",
                            floor_condition = floor_cond)
      ti <- recommend_titer(sw, "medium")
      ip <- interpret_mark(m, sw, ti, label_pos = paste(lab_hi, "cells"), label_neg = paste(lab_lo, "cells"))
      list(marker = m, trajectory = sw$trajectory, floor = sw$floor,
           peak_condition = sw$peak_condition, peak_auroc = sw$peak_auroc,
           knee_condition = sw$knee_condition, flags = safe_I(sw$flags %||% character(0)),
           titer = list(recommended = ti$recommended, basis = ti$basis, reliable = ti$reliable),
           interpretation = ip)
    })
    names(results) <- markers
    reliable <- names(which(vapply(results, function(r) isTRUE(r$titer$reliable), logical(1))))
    weak <- setdiff(markers, reliable)
    contrast_caveat <- if (matched_dna)
      "M and G2 share ~4N DNA, so copy number is matched; condensed mitotic chromatin can still affect epitopes."
      else if (setequal(ph_hi, "S"))
      "S-phase cells have partially replicated DNA, so this contrast is correlated with DNA content."
      else
      "G1 and G2/M differ in DNA content and chromatin compaction as well as in mark level."
    panel <- list(
      controls = paste0("Cell-cycle reference: ", lab_hi, " vs ", lab_lo,
                        ". Raw per-phase intensity across the concentration series; interpret alongside a population or FMO titration. ",
                        contrast_caveat,
                        " Method: Golden et al., bioRxiv 2024 (doi.org/10.1101/2024.10.03.616268)."),
      confidence = "Recommended concentration is where the cell-cycle contrast is best resolved. A mark that is stable across the cycle shows weak separation, which reflects small biology rather than a poor antibody.",
      summary = if (length(reliable))
                  paste0("Resolves the contrast for: ", paste(reliable, collapse = ", "),
                         ". Cycle-stable (weak here): ", if (length(weak)) paste(weak, collapse = ", ") else "none", ".")
                else "No mark clearly resolves this cell-cycle contrast; try another phase pair or rely on the saturation curve and an FMO.",
      negative_note = "")
    return(list(markers = safe_I(markers),
                negative = list(type = "cellcycle", ids = safe_I(c(ph_hi, ph_lo)), confidence = "medium", quality = NULL),
                results = results, panel = panel))
  }

  controls <- detect_controls(d, blank_condition = floor_cond)
  rec_neg  <- recommend_negative(controls, data = d, pos_ids = pos_ids,
                                 floor_condition = floor_cond, force_neg = p$neg_ids)
  neg_ids  <- rec_neg$ids
  if (is.null(neg_ids) || length(neg_ids) == 0)
    return(list(error = "No usable negative population found; pass neg_ids explicitly."))

  results <- lapply(markers, function(m) {
    sw <- titration_sweep(d, m, pos_ids = pos_ids, neg_ids = neg_ids, floor_condition = floor_cond)
    ti <- recommend_titer(sw, rec_neg$confidence)
    ip <- interpret_mark(m, sw, ti)
    list(marker = m, trajectory = sw$trajectory, floor = sw$floor,
         peak_condition = sw$peak_condition, peak_auroc = sw$peak_auroc,
         knee_condition = sw$knee_condition, flags = safe_I(sw$flags %||% character(0)),
         titer = list(recommended = ti$recommended, basis = ti$basis, reliable = ti$reliable),
         interpretation = ip)
  })
  names(results) <- markers
  mark_titers <- lapply(results, function(r) list(reliable = r$titer$reliable))
  panel <- interpret_panel(controls, rec_neg, mark_titers)

  list(markers = safe_I(markers),
       negative = list(type = rec_neg$type, ids = safe_I(neg_ids), confidence = rec_neg$confidence,
                       quality = if (is.null(rec_neg$quality)) NULL else rec_neg$quality$verdict),
       results = results, panel = panel)
}
